/**
 * Formatador de valores monetários em Real Brasileiro
 * @param {number} value - Valor a ser formatado
 * @returns {string} - Valor formatado (ex: R$ 1.234,56)
 */
export const formatCurrency = (value) => {
  if (value === null || value === undefined || isNaN(value)) {
    return 'R$ 0,00';
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

/**
 * Formatador de data em português brasileiro
 * @param {string|Date} date - Data a ser formatada
 * @returns {string} - Data formatada (ex: 10 de março de 2026)
 */
export const formatDate = (date) => {
  const dateObj = typeof date === 'string' ? new Date(date + 'T12:00:00') : date;
  return dateObj.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
};

/**
 * Formatador de data curta
 * @param {string|Date} date - Data a ser formatada
 * @returns {string} - Data formatada (ex: 10/03/2026)
 */
export const formatDateShort = (date) => {
  const dateObj = typeof date === 'string' ? new Date(date + 'T12:00:00') : date;
  return dateObj.toLocaleDateString('pt-BR');
};

/**
 * Formatador de CPF
 * @param {string} cpf - CPF a ser formatado
 * @returns {string} - CPF formatado (ex: 123.456.789-00)
 */
export const formatCPF = (cpf) => {
  if (!cpf) return '';
  const cleaned = cpf.replace(/\D/g, '');
  return cleaned.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
};

/**
 * Formatador de telefone
 * @param {string} phone - Telefone a ser formatado
 * @returns {string} - Telefone formatado (ex: (11) 98765-4321)
 */
export const formatPhone = (phone) => {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 11) {
    return cleaned.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  }
  return cleaned.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
};
