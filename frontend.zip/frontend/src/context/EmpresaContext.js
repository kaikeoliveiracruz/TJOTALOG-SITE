import React, { createContext, useContext, useState, useEffect } from 'react';

const EmpresaContext = createContext();

export const useEmpresa = () => {
  const context = useContext(EmpresaContext);
  if (!context) {
    throw new Error('useEmpresa must be used within EmpresaProvider');
  }
  return context;
};

export const EmpresaProvider = ({ children }) => {
  const [empresaSelecionada, setEmpresaSelecionada] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const empresaId = localStorage.getItem('empresa_selecionada');
    if (empresaId) {
      setEmpresaSelecionada(empresaId);
    }
    setLoading(false);
  }, []);

  const selecionarEmpresa = (empresaId) => {
    localStorage.setItem('empresa_selecionada', empresaId);
    setEmpresaSelecionada(empresaId);
  };

  const limparEmpresa = () => {
    localStorage.removeItem('empresa_selecionada');
    setEmpresaSelecionada(null);
  };

  return (
    <EmpresaContext.Provider value={{ empresaSelecionada, selecionarEmpresa, limparEmpresa, loading }}>
      {children}
    </EmpresaContext.Provider>
  );
};