import React from 'react';

const EmptyState = ({ message, description, icon: Icon }) => {
  return (
    <div className="col-span-full text-center py-12">
      {Icon && <Icon size={48} className="mx-auto text-muted-foreground mb-4" />}
      <p className="text-muted-foreground">{message}</p>
      {description && <p className="text-sm text-muted-foreground mt-2">{description}</p>}
    </div>
  );
};

export default EmptyState;
