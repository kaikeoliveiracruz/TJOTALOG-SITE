import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { X } from 'lucide-react';

const IntroButton = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Botão flutuante com logo menor */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-20 right-4 md:bottom-6 md:right-6 z-50 w-14 h-14 md:w-16 md:h-16 rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105 overflow-hidden border-2 border-white/50 bg-white"
        title="Sobre o TJOTALOG"
        data-testid="intro-button"
      >
        <img
          src="/logo.jpeg"
          alt="TJOTALOG"
          className="w-full h-full object-cover"
        />
      </button>

      {/* Modal de Introdução */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-2xl">
              <img src="/logo.jpeg" alt="TJOTALOG" className="w-12 h-12 rounded-lg object-cover" />
              TJOTALOG
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 text-muted-foreground leading-relaxed">
            <p className="text-foreground font-medium">
              Bom dia, meu chefe! Tudo bem?
            </p>
            
            <p>
              Notei que muitos donos de transportadora sofrem com a mesma coisa: o dinheiro sai nas diárias e custos de base, mas o fechamento semanal nunca bate 100%.
            </p>
            
            <p>
              Desenvolvi o <strong className="text-primary">TJOTALOG</strong>, um app de gestão focado exclusivamente em Base e Operação. Com ele você consegue:
            </p>
            
            <ul className="space-y-3 pl-2">
              <li className="flex items-start gap-2">
                <span className="text-accent font-bold">•</span>
                <span><strong>Controlar Diárias:</strong> Pague e registre tudo pelo celular, sem papelada.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent font-bold">•</span>
                <span><strong>Gerir Funcionários:</strong> Saiba quem está na base e qual a função de cada um em tempo real.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent font-bold">•</span>
                <span><strong>Fechamento Semanal Automático:</strong> Veja quanto gastou na semana com um clique.</span>
              </li>
            </ul>
            
            <p className="text-foreground font-medium pt-2">
              Topa dar uma olhada em como ele funciona? Garanto que você vai ter uma visão da sua transportadora que nunca teve antes.
            </p>
            
            <p className="text-foreground font-semibold">
              Abraço!
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default IntroButton;
