import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Users, Briefcase, CheckSquare, BarChart3, Building2 } from 'lucide-react';

const BottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'Início' },
    { path: '/funcionarios', icon: Users, label: 'Equipe' },
    { path: '/cargos', icon: Briefcase, label: 'Cargos' },
    { path: '/presenca', icon: CheckSquare, label: 'Presença' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },
    { path: '/empresas', icon: Building2, label: 'Empresa' }
  ];

return (
  <nav
    className="fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700"
    style={{
      paddingBottom: 'env(safe-area-inset-bottom)',
    }}
  >
    <div className="max-w-7xl mx-auto flex justify-around items-center">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.path;

        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center justify-center py-2 px-2 transition-colors ${
              isActive
                ? 'text-blue-500 dark:text-blue-400'
                : 'text-gray-500 dark:text-gray-400'
            }`}
            data-testid={`nav-${item.label.toLowerCase()}`}
          >
            <Icon size={20} />
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        );
      })}
    </div>
  </nav>
);
};

export default BottomNav;