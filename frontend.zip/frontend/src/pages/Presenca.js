import { empresasAPI, cargosAPI, funcionariosAPI, presencasAPI, uploadAPI } from '../lib/api';
import React, { useEffect, useState } from 'react';
import { useEmpresa } from '../context/EmpresaContext';
import { toast } from 'sonner';
import { Calendar, DollarSign, Plus } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import LoadingSpinner from '../components/shared/LoadingSpinner';




const Presenca = () => {
  const { empresaSelecionada } = useEmpresa();
  const [funcionarios, setFuncionarios] = useState([]);
  const [presencas, setPresencas] = useState({});
  const [dataAtual, setDataAtual] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);
  const [valorExtraDialog, setValorExtraDialog] = useState({ open: false, funcionario: null });
  const [valorExtra, setValorExtra] = useState('0');

  useEffect(() => {
    if (empresaSelecionada) {
      fetchData();
    }
  }, [dataAtual, empresaSelecionada]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [funcionariosRes, presencasRes] = await Promise.all([
        funcionariosAPI.getAll(empresaSelecionada),
        presencasAPI.getByDay(dataAtual, empresaSelecionada)
      ]);
      
      setFuncionarios(funcionariosRes.data);
      
      const presencasMap = {};
      presencasRes.data.forEach(p => {
        presencasMap[p.funcionario_id] = p.presente;
      });
      setPresencas(presencasMap);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const togglePresenca = async (funcionarioId, presente, valorExtraValor = 0) => {
    try {
      await presencasAPI.create({
        funcionario_id: funcionarioId,
        empresa_id: empresaSelecionada,
        data: dataAtual,
        presente: presente,
        valor_extra: valorExtraValor  // Valor extra específico deste dia
      });
      
      setPresencas(prev => ({ ...prev, [funcionarioId]: presente }));
      toast.success(presente ? 'Presença marcada' : 'Ausência marcada');
      fetchData(); // Recarregar para atualizar valores
    } catch (error) {
      console.error('Erro ao registrar presença:', error);
      toast.error('Erro ao registrar presença');
    }
  };
  
  const handlePresencaComExtra = (funcionario) => {
    setValorExtraDialog({ open: true, funcionario });
    setValorExtra('0');
  };
  
  const confirmarPresencaComExtra = async () => {
    if (!valorExtraDialog.funcionario) return;
    
    const valor = parseFloat(valorExtra) || 0;
    await togglePresenca(valorExtraDialog.funcionario.id, true, valor);
    setValorExtraDialog({ open: false, funcionario: null });
    setValorExtra('0');
  };

  if (loading) {
    return <LoadingSpinner message="Carregando presenças..." />;
  }

  const dataObj = new Date(dataAtual + 'T12:00:00');
  const dataFormatada = dataObj.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  const diaSemana = dataObj.toLocaleDateString('pt-BR', { weekday: 'long' });

  const totalPresentes = Object.values(presencas).filter(p => p === true).length;
  const totalAusentes = Object.values(presencas).filter(p => p === false).length;
  const totalMarcados = totalPresentes + totalAusentes;

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="presenca-title">Registro de Presença</h1>
        <p className="text-sm text-muted-foreground">Marque a presença da equipe em qualquer dia</p>
      </header>

      <div className="mb-6 p-5 bg-card rounded-md border border-border">
        <div className="flex items-center gap-3 mb-3">
          <Calendar className="text-accent" size={24} />
          <div>
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">{diaSemana}</p>
            <p className="text-base font-semibold text-foreground">{dataFormatada}</p>
          </div>
        </div>
        <input
          type="date"
          value={dataAtual}
          onChange={(e) => setDataAtual(e.target.value)}
          className="w-full p-3 border border-input rounded-md bg-background text-foreground"
          data-testid="date-picker"
        />
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-secondary rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Marcados</p>
            <p className="text-2xl font-bold text-primary">{totalMarcados}</p>
          </div>
          <div className="text-center p-3 bg-success/10 rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Presentes</p>
            <p className="text-2xl font-bold text-success">{totalPresentes}</p>
          </div>
          <div className="text-center p-3 bg-destructive/10 rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Ausentes</p>
            <p className="text-2xl font-bold text-destructive">{totalAusentes}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {funcionarios.length === 0 ? (
          <div className="col-span-full text-center py-12" data-testid="empty-funcionarios-presenca">
            <p className="text-muted-foreground">Nenhum funcionário cadastrado.</p>
            <p className="text-sm text-muted-foreground mt-2">Adicione funcionários primeiro.</p>
          </div>
        ) : (
          funcionarios.map((funcionario) => {
            const presente = presencas[funcionario.id];
            return (
              <div
                key={funcionario.id}
                className="employee-card p-5 rounded-md"
                data-testid={`presenca-card-${funcionario.id}`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{funcionario.nome}</h3>
                    <p className="text-sm text-muted-foreground uppercase tracking-wide font-medium mt-1">
                      {funcionario.cargo_nome}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-2">
                  <Button
                    onClick={() => togglePresenca(funcionario.id, true)}
                    className={`presence-toggle ${
                      presente === true
                        ? 'bg-success text-white hover:bg-success/90'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                    data-testid={`presenca-sim-${funcionario.id}`}
                  >
                    Presente
                  </Button>
                  <Button
                    onClick={() => togglePresenca(funcionario.id, false)}
                    className={`presence-toggle ${
                      presente === false
                        ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                    data-testid={`presenca-nao-${funcionario.id}`}
                  >
                    Ausente
                  </Button>
                </div>
                <Button
                  onClick={() => handlePresencaComExtra(funcionario)}
                  variant="outline"
                  className="w-full text-xs bg-accent/10 hover:bg-accent/20 border-accent text-accent-foreground"
                  data-testid={`presenca-extra-${funcionario.id}`}
                >
                  <DollarSign size={14} className="mr-1" />
                  Presente + Valor Extra
                </Button>
              </div>
            );
          })
        )}
      </div>

      {/* Dialog para Valor Extra */}
      <Dialog open={valorExtraDialog.open} onOpenChange={(open) => setValorExtraDialog({ open, funcionario: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Valor Extra</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              Adicione um valor extra para <strong>{valorExtraDialog.funcionario?.nome}</strong> apenas para este dia ({dataFormatada})
            </p>
            <div className="space-y-2">
              <Label htmlFor="valor-extra-dia">Valor Extra (R$)</Label>
              <Input
                id="valor-extra-dia"
                type="number"
                step="0.01"
                min="0"
                value={valorExtra}
                onChange={(e) => setValorExtra(e.target.value)}
                placeholder="0.00"
                className="w-full"
                data-testid="valor-extra-input"
              />
              <p className="text-xs text-muted-foreground">
                Este valor será adicionado APENAS à diária de hoje
              </p>
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setValorExtraDialog({ open: false, funcionario: null })}>
              Cancelar
            </Button>
            <Button onClick={confirmarPresencaComExtra} className="bg-accent" data-testid="confirmar-valor-extra">
              Confirmar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Presenca;
