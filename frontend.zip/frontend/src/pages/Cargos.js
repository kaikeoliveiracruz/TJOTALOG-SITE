import { empresasAPI, cargosAPI, funcionariosAPI, presencasAPI, uploadAPI } from '../lib/api';
import React, { useEffect, useState } from 'react';

import { useEmpresa } from '../context/EmpresaContext';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';




const Cargos = () => {
  const { empresaSelecionada } = useEmpresa();
  const [cargos, setCargos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingCargo, setEditingCargo] = useState(null);
  const [cargoToDelete, setCargoToDelete] = useState(null);
  const [formData, setFormData] = useState({
    nome: '',
    valor_diaria_padrao: ''
  });

  useEffect(() => {
    if (empresaSelecionada) {
      fetchCargos();
    }
  }, [empresaSelecionada]);

  const fetchCargos = async () => {
    try {
      const response = await cargosAPI.getAll(empresaSelecionada);
      setCargos(response.data);
    } catch (error) {
      console.error('Erro ao carregar cargos:', error);
      toast.error('Erro ao carregar cargos');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.valor_diaria_padrao) {
      toast.error('Preencha todos os campos');
      return;
    }

    try {
      const data = {
        nome: formData.nome,
        valor_diaria_padrao: parseFloat(formData.valor_diaria_padrao),
        empresa_id: empresaSelecionada
      };

      if (editingCargo) {
        await cargosAPI.update(editingCargo.id, data);
        toast.success('Cargo atualizado com sucesso');
      } else {
        await cargosAPI.create(data);
        toast.success('Cargo criado com sucesso');
      }

      setDialogOpen(false);
      setEditingCargo(null);
      setFormData({ nome: '', valor_diaria_padrao: '' });
      fetchCargos();
    } catch (error) {
      console.error('Erro ao salvar cargo:', error);
      toast.error('Erro ao salvar cargo');
    }
  };

  const handleEdit = (cargo) => {
    setEditingCargo(cargo);
    setFormData({
      nome: cargo.nome,
      valor_diaria_padrao: cargo.valor_diaria_padrao.toString()
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    try {
      await cargosAPI.delete(cargoToDelete.id);
      toast.success('Cargo deletado com sucesso');
      setDeleteDialogOpen(false);
      setCargoToDelete(null);
      fetchCargos();
    } catch (error) {
      console.error('Erro ao deletar cargo:', error);
      toast.error('Erro ao deletar cargo');
    }
  };

  const openDeleteDialog = (cargo) => {
    setCargoToDelete(cargo);
    setDeleteDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({ nome: '', valor_diaria_padrao: '' });
    setEditingCargo(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="cargos-title">Gestão de Cargos</h1>
        <p className="text-sm text-muted-foreground">Adicione e gerencie cargos da empresa</p>
      </header>

      <Dialog open={dialogOpen} onOpenChange={(open) => {
        setDialogOpen(open);
        if (!open) resetForm();
      }}>
        <DialogTrigger asChild>
          <Button className="w-full md:w-auto mb-6 btn-accent" data-testid="add-cargo-button">
            <Plus size={20} className="mr-2" />
            Adicionar Cargo
          </Button>
        </DialogTrigger>
        <DialogContent data-testid="cargo-dialog">
          <DialogHeader>
            <DialogTitle>{editingCargo ? 'Editar Cargo' : 'Novo Cargo'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome do Cargo</Label>
              <Input
                id="nome"
                data-testid="cargo-nome-input"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: Motorista, Ajudante"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="valor">Valor da Diária Padrão (R$)</Label>
              <Input
                id="valor"
                data-testid="cargo-valor-input"
                type="number"
                step="0.01"
                value={formData.valor_diaria_padrao}
                onChange={(e) => setFormData({ ...formData, valor_diaria_padrao: e.target.value })}
                placeholder="Ex: 150.00"
                className="mt-1"
              />
            </div>
            <Button type="submit" className="w-full" data-testid="cargo-submit-button">
              {editingCargo ? 'Atualizar' : 'Criar'} Cargo
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {cargos.length === 0 ? (
          <div className="col-span-full text-center py-12" data-testid="empty-cargos">
            <p className="text-muted-foreground">Nenhum cargo cadastrado ainda.</p>
            <p className="text-sm text-muted-foreground mt-2">Clique no botão acima para adicionar.</p>
          </div>
        ) : (
          cargos.map((cargo) => (
            <div
              key={cargo.id}
              className="employee-card p-5 rounded-md"
              data-testid={`cargo-card-${cargo.id}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground">{cargo.nome}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Diária padrão: <span className="font-bold text-accent">R$ {cargo.valor_diaria_padrao.toFixed(2)}</span>
                  </p>
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => handleEdit(cargo)}
                    className="p-2 hover:bg-secondary rounded-md transition-colors"
                    data-testid={`edit-cargo-${cargo.id}`}
                  >
                    <Edit2 size={18} className="text-primary" />
                  </button>
                  <button
                    onClick={() => openDeleteDialog(cargo)}
                    className="p-2 hover:bg-destructive/10 rounded-md transition-colors"
                    data-testid={`delete-cargo-${cargo.id}`}
                  >
                    <Trash2 size={18} className="text-destructive" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o cargo "{cargoToDelete?.nome}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Cargos;
