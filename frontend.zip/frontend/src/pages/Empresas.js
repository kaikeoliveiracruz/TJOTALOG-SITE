import { empresasAPI, cargosAPI, funcionariosAPI, presencasAPI, uploadAPI } from '../lib/api';
import React, { useEffect, useState } from 'react';

import { useEmpresa } from '../context/EmpresaContext';
import { Building2, Plus, Edit2, MapPin, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { useNavigate } from 'react-router-dom';




const Empresas = () => {
  const { empresaSelecionada, selecionarEmpresa, limparEmpresa } = useEmpresa();
  const [empresas, setEmpresas] = useState([]);
  const [empresaAtual, setEmpresaAtual] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEmpresa, setEditingEmpresa] = useState(null);
  const [formData, setFormData] = useState({ nome: '', local_atuacao: '' });
  const [empresaToDelete, setEmpresaToDelete] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchEmpresas();
  }, []);

  const fetchEmpresas = async () => {
    try {
      const response = await empresasAPI.getAll();
      setEmpresas(response.data);
      const atual = response.data.find(e => e.id === empresaSelecionada);
      setEmpresaAtual(atual);
    } catch (error) {
      console.error('Erro ao carregar empresas:', error);
      toast.error('Erro ao carregar empresas');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.nome || !formData.local_atuacao) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    try {
      if (editingEmpresa) {
        await empresasAPI.update(editingEmpresa.id, formData);
        toast.success('Empresa atualizada com sucesso');
      } else {
        await empresasAPI.create(formData);
        toast.success('Empresa criada com sucesso');
      }
      setDialogOpen(false);
      setEditingEmpresa(null);
      setFormData({ nome: '', local_atuacao: '' });
      fetchEmpresas();
    } catch (error) {
      console.error('Erro ao salvar empresa:', error);
      toast.error('Erro ao salvar empresa');
    }
  };

  const handleEdit = (empresa) => {
    setEditingEmpresa(empresa);
    setFormData({
      nome: empresa.nome,
      local_atuacao: empresa.local_atuacao
    });
    setDialogOpen(true);
  };

  const confirmDelete = (empresa) => {
    setEmpresaToDelete(empresa);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!empresaToDelete) return;
    
    try {
      await empresasAPI.delete(empresaToDelete.id);
      toast.success('Empresa excluída com sucesso');
      
      // Se a empresa excluída era a atual, limpar seleção
      if (empresaToDelete.id === empresaSelecionada) {
        limparEmpresa();
        navigate('/selecionar-empresa');
      }
      
      setDeleteDialogOpen(false);
      setEmpresaToDelete(null);
      fetchEmpresas();
    } catch (error) {
      console.error('Erro ao excluir empresa:', error);
      toast.error('Erro ao excluir empresa');
    }
  };

  const handleTrocarEmpresa = (empresaId) => {
    selecionarEmpresa(empresaId);
    toast.success('Empresa alterada com sucesso');
    navigate('/');
  };

  const resetForm = () => {
    setFormData({ nome: '', local_atuacao: '' });
    setEditingEmpresa(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="empresas-title">Gestão de Empresas</h1>
        <p className="text-sm text-muted-foreground">Gerencie e alterne entre suas empresas</p>
      </header>

      {empresaAtual && (
        <div className="mb-8 p-6 bg-accent/10 border-2 border-accent rounded-md">
          <div className="flex items-center gap-4">
            {empresaAtual.imagem_url ? (
              <img
                src={empresaAtual.imagem_url}
                alt={empresaAtual.nome}
                className="w-16 h-16 object-cover rounded-md"
              />
            ) : (
              <div className="w-16 h-16 bg-secondary rounded-md flex items-center justify-center">
                <Building2 size={32} className="text-muted-foreground" />
              </div>
            )}
            <div className="flex-1">
              <p className="text-xs text-accent font-semibold uppercase tracking-wider mb-1">Empresa Atual</p>
              <h2 className="text-xl font-bold text-foreground">{empresaAtual.nome}</h2>
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                <MapPin size={14} />
                {empresaAtual.local_atuacao}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleEdit(empresaAtual)}
              data-testid="edit-empresa-atual"
            >
              <Edit2 size={16} className="mr-2" />
              Editar
            </Button>
          </div>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={(open) => {
        setDialogOpen(open);
        if (!open) resetForm();
      }}>
        <DialogTrigger asChild>
          <Button className="w-full md:w-auto mb-6 btn-accent" data-testid="add-empresa-button">
            <Plus size={20} className="mr-2" />
            Nova Empresa
          </Button>
        </DialogTrigger>
        <DialogContent data-testid="empresa-dialog">
          <DialogHeader>
            <DialogTitle>{editingEmpresa ? 'Editar Empresa' : 'Nova Empresa'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome da Empresa *</Label>
              <Input
                id="nome"
                data-testid="empresa-nome-input"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: Transportes Silva"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="local">Local de Atuação *</Label>
              <Input
                id="local"
                data-testid="empresa-local-input"
                value={formData.local_atuacao}
                onChange={(e) => setFormData({ ...formData, local_atuacao: e.target.value })}
                placeholder="Ex: São Paulo - SP"
                className="mt-1"
              />
            </div>
            <Button type="submit" className="w-full" data-testid="empresa-submit-button">
              {editingEmpresa ? 'Atualizar' : 'Criar'} Empresa
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <h3 className="text-lg font-semibold text-foreground mb-4">Todas as Empresas</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {empresas.map((empresa) => {
          const isAtual = empresa.id === empresaSelecionada;
          return (
            <div
              key={empresa.id}
              className={`employee-card p-6 rounded-md ${isAtual ? 'border-2 border-accent' : ''}`}
              data-testid={`empresa-card-${empresa.id}`}
            >
              {empresa.imagem_url ? (
                <img
                  src={empresa.imagem_url}
                  alt={empresa.nome}
                  className="w-full h-32 object-cover rounded-md mb-4"
                />
              ) : (
                <div className="w-full h-32 bg-secondary rounded-md mb-4 flex items-center justify-center">
                  <Building2 size={48} className="text-muted-foreground" />
                </div>
              )}
              <h3 className="text-xl font-bold text-foreground mb-2">{empresa.nome}</h3>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                <MapPin size={16} />
                <span>{empresa.local_atuacao}</span>
              </div>
              <div className="flex gap-2">
                {!isAtual && (
                  <Button
                    onClick={() => handleTrocarEmpresa(empresa.id)}
                    className="flex-1"
                    size="sm"
                    data-testid={`trocar-empresa-${empresa.id}`}
                  >
                    Selecionar
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => handleEdit(empresa)}
                  className="flex-1"
                  size="sm"
                  data-testid={`edit-empresa-${empresa.id}`}
                >
                  <Edit2 size={16} className="mr-2" />
                  Editar
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => confirmDelete(empresa)}
                  size="sm"
                  data-testid={`delete-empresa-${empresa.id}`}
                >
                  <Trash2 size={16} />
                </Button>
              </div>
              {isAtual && (
                <div className="mt-3 text-center text-xs text-accent font-semibold uppercase tracking-wide">
                  Empresa Atual
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Alert Dialog para confirmação de exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Empresa</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a empresa <strong>{empresaToDelete?.nome}</strong>?
              <br /><br />
              Esta ação não pode ser desfeita e todos os dados relacionados (funcionários, cargos, presenças) serão perdidos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Empresas;