import React, { useState, useEffect } from 'react';
import { useEmpresa } from '../context/EmpresaContext';
import { toast } from 'sonner';
import { Download, TrendingUp, Trash2, DollarSign } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { relatoriosAPI, presencasAPI, funcionariosAPI } from '../lib/api';

const Relatorios = () => {
  const { empresaSelecionada } = useEmpresa();
  const [relatorioSemanal, setRelatorioSemanal] = useState(null);
  const [relatorioMensal, setRelatorioMensal] = useState(null);
  const [relatorioPeriodo, setRelatorioPeriodo] = useState(null);
  const [dataSemanal, setDataSemanal] = useState('');
  const [mesSelecionado, setMesSelecionado] = useState({ ano: new Date().getFullYear(), mes: new Date().getMonth() + 1 });
  const [dataInicioPeriodo, setDataInicioPeriodo] = useState('');
  const [dataFimPeriodo, setDataFimPeriodo] = useState('');
  const [loading, setLoading] = useState(false);
  const [presencaToDelete, setPresencaToDelete] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  useEffect(() => {
    const hoje = new Date();
    const diaSemana = hoje.getDay();
    const segundaFeira = new Date(hoje);
    segundaFeira.setDate(hoje.getDate() - (diaSemana === 0 ? 6 : diaSemana - 1));
    setDataSemanal(segundaFeira.toISOString().split('T')[0]);
  }, []);

  useEffect(() => {
    if (dataSemanal && empresaSelecionada) {
      fetchRelatorioSemanal();
    }
  }, [dataSemanal, empresaSelecionada]);

  useEffect(() => {
    if (empresaSelecionada) {
      fetchRelatorioMensal();
    }
  }, [mesSelecionado, empresaSelecionada]);

  const fetchRelatorioSemanal = async () => {
    if (!dataSemanal || !empresaSelecionada) return;
    setLoading(true);
    try {
      const response = await relatoriosAPI.getSemanal(empresaSelecionada, dataSemanal);
      // Backend agora retorna valor_extra e valor_diaria_base diretamente! 🚀
      setRelatorioSemanal(response.data);
    } catch (error) {
      console.error('Erro ao buscar relatório semanal:', error);
      toast.error('Erro ao carregar relatório');
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatorioMensal = async () => {
    setLoading(true);
    try {
      const response = await relatoriosAPI.getMensal(empresaSelecionada, mesSelecionado.ano, mesSelecionado.mes);
      setRelatorioMensal(response.data);
    } catch (error) {
      console.error('Erro ao carregar relatório mensal:', error);
      toast.error('Erro ao carregar relatório mensal');
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatorioPeriodo = async () => {
    if (!dataInicioPeriodo || !dataFimPeriodo) {
      toast.error('Selecione as datas de início e fim');
      return;
    }
    
    if (dataFimPeriodo < dataInicioPeriodo) {
      toast.error('Data final deve ser maior que data inicial');
      return;
    }
    
    setLoading(true);
    try {
      // Usar endpoint existente de presencas mas calcular manualmente
      const response = await presencasAPI.getAll(empresaSelecionada, dataInicioPeriodo, dataFimPeriodo);
      
      // Agrupar por funcionário
      const presencas = response.data.filter(p => p.presente);
      const funcionariosMap = {};
      
      for (const presenca of presencas) {
        const funcId = presenca.funcionario_id;
        if (!funcionariosMap[funcId]) {
          const funcResponse = await funcionariosAPI.getById(funcId);
          const funcionario = funcResponse.data;
          funcionariosMap[funcId] = {
            funcionario_id: funcId,
            funcionario_nome: funcionario.nome,
            total_dias: 0,
            valor_total: 0,
            total_extras: 0,
            valor_diaria_base: funcionario.valor_diaria_personalizado || 0
          };
        }
        
        const valorExtra = presenca.valor_extra || 0;
        funcionariosMap[funcId].total_dias += 1;
        funcionariosMap[funcId].valor_total += presenca.valor_diaria;
        funcionariosMap[funcId].total_extras += valorExtra;
      }
      
      setRelatorioPeriodo({
        periodo: { inicio: dataInicioPeriodo, fim: dataFimPeriodo },
        funcionarios: Object.values(funcionariosMap)
      });
    } catch (error) {
      console.error('Erro ao carregar relatório de período:', error);
      toast.error('Erro ao carregar relatório');
    } finally {
      setLoading(false);
    }
  };

  const exportarCSV = async (dataInicio, dataFim) => {
    try {
      const response = await relatoriosAPI.exportCSV(empresaSelecionada, dataInicio, dataFim);
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `relatorio_${dataInicio}_${dataFim}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('Relatório exportado com sucesso');
    } catch (error) {
      console.error('Erro ao exportar CSV:', error);
      toast.error('Erro ao exportar relatório');
    }
  };

  const mudarSemana = (dias) => {
    const novaData = new Date(dataSemanal);
    novaData.setDate(novaData.getDate() + dias);
    setDataSemanal(novaData.toISOString().split('T')[0]);
  };

  const mudarMes = (meses) => {
    const novoMes = mesSelecionado.mes + meses;
    let ano = mesSelecionado.ano;
    let mes = novoMes;
    
    if (mes > 12) {
      mes = 1;
      ano += 1;
    } else if (mes < 1) {
      mes = 12;
      ano -= 1;
    }
    
    setMesSelecionado({ ano, mes });
  };

  const handleDeletePresencas = async (funcionarioId, funcionarioNome) => {
    // Buscar todas as presenças do funcionário no período atual
    const dataInicio = dataSemanal;
    const dataFim = new Date(dataSemanal);
    dataFim.setDate(dataFim.getDate() + 6);
    const dataFimStr = dataFim.toISOString().split('T')[0];
    
    try {
      const response = await presencasAPI.getAll(empresaSelecionada, dataInicio, dataFimStr);
      const presencasFuncionario = response.data.filter(p => p.funcionario_id === funcionarioId);
      
      if (presencasFuncionario.length > 0) {
        setPresencaToDelete({
          presencas: presencasFuncionario,
          funcionarioNome: funcionarioNome
        });
        setDeleteDialogOpen(true);
      } else {
        toast.error('Nenhuma presença encontrada para este funcionário');
      }
    } catch (error) {
      console.error('Erro ao buscar presenças:', error);
      toast.error('Erro ao buscar presenças');
    }
  };

  const confirmDelete = async () => {
    if (!presencaToDelete || !presencaToDelete.presencas) return;
    
    try {
      // Excluir todas as presenças do funcionário no período
      for (const presenca of presencaToDelete.presencas) {
        await presencasAPI.delete(presenca.id);
      }
      
      toast.success(`${presencaToDelete.presencas.length} presença(s) excluída(s) com sucesso`);
      setDeleteDialogOpen(false);
      setPresencaToDelete(null);
      
      // Recarregar relatório
      fetchRelatorioSemanal();
    } catch (error) {
      console.error('Erro ao excluir presenças:', error);
      toast.error('Erro ao excluir presenças');
    }
  };



  const formatarData = (data) => {
    return new Date(data + 'T12:00:00').toLocaleDateString('pt-BR');
  };

  const meses = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="relatorios-title">Relatórios</h1>
        <p className="text-sm text-muted-foreground">Visualize e exporte relatórios</p>
      </header>

      <Tabs defaultValue="semanal" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="semanal" data-testid="tab-semanal">Semanal</TabsTrigger>
          <TabsTrigger value="mensal" data-testid="tab-mensal">Mensal</TabsTrigger>
          <TabsTrigger value="periodo" data-testid="tab-periodo">Período</TabsTrigger>
        </TabsList>

        <TabsContent value="semanal" data-testid="content-semanal">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
              <Button onClick={() => mudarSemana(-7)} variant="outline" size="sm" data-testid="semana-anterior">
                ← Anterior
              </Button>
              <div className="text-center">
                <p className="text-sm font-medium text-muted-foreground">Semana de</p>
                <p className="text-base font-semibold text-foreground">
                  {relatorioSemanal && `${formatarData(relatorioSemanal.periodo.inicio)} - ${formatarData(relatorioSemanal.periodo.fim)}`}
                </p>
              </div>
              <Button onClick={() => mudarSemana(7)} variant="outline" size="sm" data-testid="semana-proxima">
                Próxima →
              </Button>
            </div>

            {relatorioSemanal && relatorioSemanal.funcionarios.length > 0 && (
              <Button
                onClick={() => exportarCSV(relatorioSemanal.periodo.inicio, relatorioSemanal.periodo.fim)}
                className="w-full btn-accent"
                data-testid="export-semanal"
              >
                <Download size={18} className="mr-2" />
                Exportar CSV
              </Button>
            )}

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : relatorioSemanal && relatorioSemanal.funcionarios.length > 0 ? (
              <div className="space-y-4">
                <div className="p-5 bg-card rounded-md border border-border">
                  <div className="flex items-center gap-3 mb-4">
                    <TrendingUp className="text-accent" size={24} />
                    <h3 className="text-lg font-semibold text-foreground">Resumo da Semana</h3>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Dias</p>
                      <p className="text-2xl font-bold text-primary">
                        {relatorioSemanal.funcionarios.reduce((sum, f) => sum + f.total_dias, 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Diárias Base</p>
                      <p className="text-xl font-bold text-foreground">
                        R$ {relatorioSemanal.funcionarios.reduce((sum, f) => sum + (f.valor_total - (f.total_extras || 0)), 0).toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Extras</p>
                      <p className="text-xl font-bold text-success">
                        + R$ {relatorioSemanal.funcionarios.reduce((sum, f) => sum + (f.total_extras || 0), 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground">TOTAL GERAL</p>
                    <p className="text-3xl font-bold text-accent">
                      R$ {relatorioSemanal.funcionarios.reduce((sum, f) => sum + f.valor_total, 0).toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatorioSemanal.funcionarios.map((func) => (
                    <div key={func.funcionario_id} className="employee-card p-5 rounded-md relative" data-testid={`relatorio-func-${func.funcionario_id}`}>
                      <div className="absolute top-3 right-3">
                        <button
                          onClick={() => handleDeletePresencas(func.funcionario_id, func.funcionario_nome)}
                          className="p-1.5 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90 transition-colors"
                          data-testid={`delete-func-${func.funcionario_id}`}
                          title="Excluir presenças desta semana"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      
                      <h4 className="font-semibold text-foreground mb-3 pr-20">{func.funcionario_nome}</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Dias Trabalhados</p>
                          <p className="text-xl font-bold text-primary">{func.total_dias}</p>
                        </div>
                        
                        {func.total_extras > 0 ? (
                          <div className="space-y-2">
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-muted-foreground">Total em diárias base</span>
                              <span className="font-medium">R$ {(func.valor_total - func.total_extras).toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-success font-medium">Total em extras</span>
                              <span className="font-medium text-success">+ R$ {func.total_extras.toFixed(2)}</span>
                            </div>
                            <div className="pt-2 border-t border-border flex justify-between items-center">
                              <span className="text-xs text-muted-foreground uppercase">TOTAL GERAL</span>
                              <span className="text-2xl font-bold text-accent">
                                R$ {func.valor_total.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="flex justify-between items-center pt-2 border-t border-border">
                            <p className="text-xs text-muted-foreground uppercase tracking-wide">TOTAL</p>
                            <p className="text-2xl font-bold text-accent">R$ {func.valor_total.toFixed(2)}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12" data-testid="empty-semanal">
                <p className="text-muted-foreground">Nenhum dado para esta semana.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="mensal" data-testid="content-mensal">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
              <Button onClick={() => mudarMes(-1)} variant="outline" size="sm" data-testid="mes-anterior">
                ← Anterior
              </Button>
              <div className="text-center">
                <p className="text-base font-semibold text-foreground">
                  {meses[mesSelecionado.mes - 1]} {mesSelecionado.ano}
                </p>
              </div>
              <Button onClick={() => mudarMes(1)} variant="outline" size="sm" data-testid="mes-proximo">
                Próximo →
              </Button>
            </div>

            {relatorioMensal && relatorioMensal.funcionarios.length > 0 && (
              <Button
                onClick={() => exportarCSV(relatorioMensal.periodo.inicio, relatorioMensal.periodo.fim)}
                className="w-full btn-accent"
                data-testid="export-mensal"
              >
                <Download size={18} className="mr-2" />
                Exportar CSV
              </Button>
            )}

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : relatorioMensal && relatorioMensal.funcionarios.length > 0 ? (
              <div className="space-y-4">
                <div className="p-5 bg-card rounded-md border border-border">
                  <div className="flex items-center gap-3 mb-4">
                    <TrendingUp className="text-accent" size={24} />
                    <h3 className="text-lg font-semibold text-foreground">Resumo do Mês</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Dias</p>
                      <p className="text-2xl font-bold text-primary">
                        {relatorioMensal.funcionarios.reduce((sum, f) => sum + f.total_dias, 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total em Diárias</p>
                      <p className="text-2xl font-bold text-accent">
                        R$ {relatorioMensal.funcionarios.reduce((sum, f) => sum + f.valor_total, 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-5 bg-card rounded-md border border-border">
                  <h4 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wide">Gráfico de Dias Trabalhados</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={relatorioMensal.funcionarios}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="funcionario_nome" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="total_dias" fill="hsl(var(--accent))" name="Dias" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatorioMensal.funcionarios.map((func) => (
                    <div key={func.funcionario_id} className="employee-card p-5 rounded-md" data-testid={`relatorio-mensal-func-${func.funcionario_id}`}>
                      <h4 className="font-semibold text-foreground mb-3">{func.funcionario_nome}</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Dias Trabalhados</p>
                          <p className="text-xl font-bold text-primary">{func.total_dias}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
                          <p className="text-xl font-bold text-accent">R$ {func.valor_total.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12" data-testid="empty-mensal">
                <p className="text-muted-foreground">Nenhum dado para este mês.</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Nova aba: Período Personalizado */}
        <TabsContent value="periodo" data-testid="content-periodo">
          <div className="space-y-4">
            <div className="p-5 bg-card rounded-md border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Selecionar Período</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="data-inicio">Data Início</Label>
                  <Input
                    id="data-inicio"
                    type="date"
                    value={dataInicioPeriodo}
                    onChange={(e) => setDataInicioPeriodo(e.target.value)}
                    className="mt-1"
                    data-testid="data-inicio-input"
                  />
                </div>
                <div>
                  <Label htmlFor="data-fim">Data Fim</Label>
                  <Input
                    id="data-fim"
                    type="date"
                    value={dataFimPeriodo}
                    onChange={(e) => setDataFimPeriodo(e.target.value)}
                    className="mt-1"
                    data-testid="data-fim-input"
                  />
                </div>
                <Button 
                  onClick={fetchRelatorioPeriodo} 
                  className="bg-accent hover:bg-accent/90"
                  data-testid="buscar-periodo-btn"
                  disabled={!dataInicioPeriodo || !dataFimPeriodo}
                >
                  <TrendingUp size={16} className="mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-muted-foreground">Carregando relatório...</p>
              </div>
            ) : relatorioPeriodo ? (
              <div className="space-y-6">
                <div className="flex justify-end">
                  <Button
                    onClick={() => exportarCSV(dataInicioPeriodo, dataFimPeriodo)}
                    variant="outline"
                    className="bg-accent text-accent-foreground hover:bg-accent/90"
                    data-testid="exportar-periodo-btn"
                  >
                    <Download size={16} className="mr-2" />
                    Exportar XLSX
                  </Button>
                </div>

                <div className="p-5 bg-card rounded-md border border-border">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="text-accent" size={24} />
                    <h3 className="text-lg font-semibold text-foreground">Resumo do Período</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {formatarData(relatorioPeriodo.periodo.inicio)} até {formatarData(relatorioPeriodo.periodo.fim)}
                  </p>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Dias</p>
                      <p className="text-2xl font-bold text-primary">
                        {relatorioPeriodo.funcionarios.reduce((sum, f) => sum + f.total_dias, 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Diárias Base</p>
                      <p className="text-xl font-bold text-foreground">
                        R$ {relatorioPeriodo.funcionarios.reduce((sum, f) => sum + (f.valor_total - (f.total_extras || 0)), 0).toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Extras</p>
                      <p className="text-xl font-bold text-success">
                        + R$ {relatorioPeriodo.funcionarios.reduce((sum, f) => sum + (f.total_extras || 0), 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground">TOTAL GERAL</p>
                    <p className="text-3xl font-bold text-accent">
                      R$ {relatorioPeriodo.funcionarios.reduce((sum, f) => sum + f.valor_total, 0).toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatorioPeriodo.funcionarios.map((func) => (
                    <div key={func.funcionario_id} className="employee-card p-5 rounded-md relative" data-testid={`relatorio-periodo-func-${func.funcionario_id}`}>
                      <h4 className="font-semibold text-foreground mb-3 pr-20">{func.funcionario_nome}</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Dias Trabalhados</p>
                          <p className="text-xl font-bold text-primary">{func.total_dias}</p>
                        </div>
                        
                        {func.total_extras > 0 ? (
                          <div className="space-y-2">
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-muted-foreground">Total em diárias base</span>
                              <span className="font-medium">R$ {(func.valor_total - func.total_extras).toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-success font-medium">Total em extras</span>
                              <span className="font-medium text-success">+ R$ {func.total_extras.toFixed(2)}</span>
                            </div>
                            <div className="pt-2 border-t border-border flex justify-between items-center">
                              <span className="text-xs text-muted-foreground uppercase">TOTAL GERAL</span>
                              <span className="text-2xl font-bold text-accent">
                                R$ {func.valor_total.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="flex justify-between items-center pt-2 border-t border-border">
                            <p className="text-xs text-muted-foreground uppercase tracking-wide">TOTAL</p>
                            <p className="text-2xl font-bold text-accent">R$ {func.valor_total.toFixed(2)}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12" data-testid="empty-periodo">
                <p className="text-muted-foreground">Selecione um período e clique em "Gerar Relatório"</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>


      {/* Alert Dialog para confirmação de exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir todas as presenças de {presencaToDelete?.funcionarioNome} desta semana?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Relatorios;