import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEmpresa } from '../context/EmpresaContext';
import { Building2, Plus, MapPin, ArrowRight, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { empresasAPI, uploadAPI } from '../lib/api';




const SelecionarEmpresa = () => {
  const [empresas, setEmpresas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({ nome: '', local_atuacao: '', imagem_url: '' });
  const [empresaToDelete, setEmpresaToDelete] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const { selecionarEmpresa } = useEmpresa();
  const navigate = useNavigate();

  useEffect(() => {
    fetchEmpresas();
  }, []);

  const fetchEmpresas = async () => {
    try {
      const response = await empresasAPI.getAll();
      setEmpresas(response.data);
    } catch (error) {
      console.error('Erro ao carregar empresas:', error);
      toast.error('Erro ao carregar empresas');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.nome || !formData.local_atuacao) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    try {
      await empresasAPI.create(formData);
      toast.success('Empresa criada com sucesso');
      setDialogOpen(false);
      setFormData({ nome: '', local_atuacao: '' });
      fetchEmpresas();
    } catch (error) {
      console.error('Erro ao criar empresa:', error);
      toast.error('Erro ao criar empresa');
    }
  };

  const confirmDelete = (empresa) => {
    setEmpresaToDelete(empresa);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!empresaToDelete) return;
    
    try {
      await empresasAPI.delete(empresaToDelete.id);
      toast.success('Empresa excluída com sucesso');
      setDeleteDialogOpen(false);
      setEmpresaToDelete(null);
      fetchEmpresas();
    } catch (error) {
      console.error('Erro ao excluir empresa:', error);
      toast.error('Erro ao excluir empresa');
    }
  };

  const handleSelecionarEmpresa = (empresaId) => {
    selecionarEmpresa(empresaId);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <header className="text-center mb-12 mt-8">
          <img 
            src="/logo.jpeg" 
            alt="TJOTALOG" 
            className="w-32 h-32 md:w-40 md:h-40 mx-auto mb-4 object-contain"
          />
          <h1 className="page-header text-5xl md:text-6xl text-primary mb-4" data-testid="selecionar-empresa-title">
            TJOTALOG
          </h1>
          <p className="text-lg text-muted-foreground">Selecione ou crie uma empresa para começar</p>
        </header>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto mb-8 btn-accent mx-auto block" size="lg" data-testid="add-empresa-button">
              <Plus size={20} className="mr-2" />
              Nova Empresa
            </Button>
          </DialogTrigger>
          <DialogContent data-testid="empresa-dialog">
            <DialogHeader>
              <DialogTitle>Nova Empresa</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome da Empresa *</Label>
                <Input
                  id="nome"
                  data-testid="empresa-nome-input"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Ex: Transportes Silva"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="local">Local de Atuação *</Label>
                <Input
                  id="local"
                  data-testid="empresa-local-input"
                  value={formData.local_atuacao}
                  onChange={(e) => setFormData({ ...formData, local_atuacao: e.target.value })}
                  placeholder="Ex: São Paulo - SP"
                  className="mt-1"
                />
              </div>
              <Button type="submit" className="w-full" data-testid="empresa-submit-button">
                Criar Empresa
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {empresas.length === 0 ? (
            <div className="col-span-full text-center py-16" data-testid="empty-empresas">
              <Building2 size={64} className="mx-auto text-muted-foreground mb-4" />
              <p className="text-lg text-muted-foreground mb-2">Nenhuma empresa cadastrada ainda.</p>
              <p className="text-sm text-muted-foreground">Clique no botão acima para criar sua primeira empresa.</p>
            </div>
          ) : (
            empresas.map((empresa) => (
              <div
                key={empresa.id}
                className="employee-card p-6 rounded-md relative group"
                data-testid={`empresa-card-${empresa.id}`}
              >
                {empresa.imagem_url ? (
                  <img
                    src={empresa.imagem_url}
                    alt={empresa.nome}
                    className="w-full h-32 object-cover rounded-md mb-4"
                  />
                ) : (
                  <div className="w-full h-32 bg-secondary rounded-md mb-4 flex items-center justify-center">
                    <Building2 size={48} className="text-muted-foreground" />
                  </div>
                )}
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    confirmDelete(empresa);
                  }}
                  className="absolute top-3 right-3 p-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90 opacity-0 group-hover:opacity-100 transition-opacity"
                  data-testid={`delete-empresa-${empresa.id}`}
                  title="Excluir empresa"
                >
                  <Trash2 size={16} />
                </button>

                <h3 className="text-xl font-bold text-foreground mb-2">{empresa.nome}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                  <MapPin size={16} />
                  <span>{empresa.local_atuacao}</span>
                </div>
                <button
                  onClick={() => handleSelecionarEmpresa(empresa.id)}
                  className="w-full flex items-center justify-center gap-2 text-accent font-semibold hover:text-accent/80 transition-colors"
                >
                  <span>Acessar</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Alert Dialog para confirmação de exclusão */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir Empresa</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir a empresa <strong>{empresaToDelete?.nome}</strong>?
                <br /><br />
                Esta ação não pode ser desfeita e todos os dados relacionados (funcionários, cargos, presenças) serão perdidos.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

export default SelecionarEmpresa;