import React, { useEffect, useState, useMemo } from 'react';
import { useEmpresa } from '../context/EmpresaContext';
import { Users, CheckCircle, DollarSign, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { funcionariosAPI, presencasAPI, empresasAPI } from '../lib/api';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import ThemeToggle from '../components/ThemeToggle';
import { formatCurrency } from '../utils/formatters';

const Dashboard = () => {
  const { empresaSelecionada, limparEmpresa } = useEmpresa();
  const [stats, setStats] = useState({
    totalFuncionarios: 0,
    presentes: 0,
    totalDiarias: 0,
    totalBase: 0,
    totalExtra: 0
  });
  const [empresaInfo, setEmpresaInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (empresaSelecionada) {
      fetchDashboardData();
      fetchEmpresaInfo();
    }
  }, [empresaSelecionada]);

  const fetchEmpresaInfo = async () => {
    try {
      const response = await empresasAPI.getById(empresaSelecionada);
      setEmpresaInfo(response.data);
    } catch (error) {
      console.error('Erro ao carregar empresa:', error);
    }
  };

  const fetchDashboardData = async () => {
    try {
      const hoje = new Date().toISOString().split('T')[0];
      const [funcionariosRes, presencasRes] = await Promise.all([
        funcionariosAPI.getAll(empresaSelecionada),
        presencasAPI.getByDay(hoje, empresaSelecionada)
      ]);

      const funcionarios = funcionariosRes.data;
      const totalFuncionarios = funcionarios.length;
      const presencas = presencasRes.data;
      const presentes = presencas.filter(p => p.presente).length;
      
      // Calcular totais com detalhamento (base + extra)
      let totalBase = 0;
      let totalExtra = 0;
      let totalDiarias = 0;
      
      presencas.filter(p => p.presente).forEach(presenca => {
        // Agora o valor_extra vem DA PRESENÇA, não do funcionário!
        const valorExtraDia = presenca.valor_extra || 0;
        const valorDiaria = presenca.valor_diaria;
        const valorBase = valorDiaria - valorExtraDia;
        
        totalBase += valorBase;
        totalExtra += valorExtraDia;
        totalDiarias += valorDiaria;
      });

      setStats({ totalFuncionarios, presentes, totalDiarias, totalBase, totalExtra });
    } catch (error) {
      console.error('Erro ao carregar dashboard:', error);
      toast.error('Erro ao carregar dados do dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleTrocarEmpresa = () => {
    limparEmpresa();
    navigate('/selecionar-empresa');
  };

  if (loading) {
    return <LoadingSpinner message="Carregando dashboard..." />;
  }

  const hoje = new Date();
  const diaSemana = hoje.toLocaleDateString('pt-BR', { weekday: 'long' });
  const dataFormatada = hoje.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-8 mt-4">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="page-header text-4xl md:text-5xl text-primary mb-2" data-testid="dashboard-title">
              {empresaInfo?.nome || 'TJOTALOG'}
            </h1>
            {empresaInfo?.local_atuacao && (
              <p className="text-sm text-muted-foreground">{empresaInfo.local_atuacao}</p>
            )}
          </div>
          <div className="flex gap-2">
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={handleTrocarEmpresa}
              data-testid="trocar-empresa-btn"
            >
              <LogOut size={16} className="mr-2" />
              Trocar Empresa
            </Button>
          </div>
        </div>
        <p className="text-sm text-muted-foreground uppercase tracking-wide font-medium">
          {diaSemana}
        </p>
        <p className="text-base text-foreground">{dataFormatada}</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="stat-card bg-card p-6 rounded-md" data-testid="stat-total-funcionarios">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Total de Funcionários</p>
              <p className="text-3xl md:text-4xl font-bold text-primary mt-2">{stats.totalFuncionarios}</p>
            </div>
            <div className="p-3 bg-secondary rounded-md">
              <Users className="text-primary" size={24} />
            </div>
          </div>
        </div>

        <div className="stat-card bg-card p-6 rounded-md" data-testid="stat-presentes">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Presentes Hoje</p>
              <p className="text-3xl md:text-4xl font-bold text-success mt-2">{stats.presentes}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-md">
              <CheckCircle className="text-success" size={24} />
            </div>
          </div>
        </div>

        <div className="stat-card bg-accent p-6 rounded-md" data-testid="stat-total-diarias">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-muted-foreground uppercase tracking-wide font-medium">Total em Diárias Hoje</p>
              <p className="text-3xl md:text-4xl font-bold text-accent-foreground mt-2">
                {formatCurrency(stats.totalDiarias)}
              </p>
              {(stats.totalBase > 0 || stats.totalExtra > 0) && (
                <p className="text-sm text-accent-foreground/80 mt-1">
                  {formatCurrency(stats.totalBase)} + {formatCurrency(stats.totalExtra)}
                </p>
              )}
            </div>
            <div className="p-3 bg-white/20 rounded-md">
              <DollarSign className="text-accent-foreground" size={24} />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-muted rounded-md border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-2">Bem-vindo ao TJOTALOG</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Gestão de Base - Sistema profissional de gestão de transportadora. Controle de presenças, cálculo de diárias e relatórios completos.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;