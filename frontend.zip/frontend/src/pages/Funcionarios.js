import React, { useEffect, useState } from 'react';
import { useEmpresa } from '../context/EmpresaContext';
import { Plus, Edit2, Trash2, Phone, CreditCard, DollarSign, Car } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { funcionariosAPI, cargosAPI, veiculosAPI } from '../lib/api';




const Funcionarios = () => {
  const { empresaSelecionada } = useEmpresa();
  const [funcionarios, setFuncionarios] = useState([]);
  const [cargos, setCargos] = useState([]);
  const [veiculos, setVeiculos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [veiculoDialogOpen, setVeiculoDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingFuncionario, setEditingFuncionario] = useState(null);
  const [funcionarioToDelete, setFuncionarioToDelete] = useState(null);
  const [selectedFuncionario, setSelectedFuncionario] = useState(null);
  const [formData, setFormData] = useState({
    nome: '',
    cargo_id: '',
    valor_diaria_personalizado: '',
    telefone: '',
    cpf: '',
    chave_pix: '',
    endereco: ''
  });
  const [veiculoFormData, setVeiculoFormData] = useState({
    placa: '',
    modelo: '',
    ano: ''
  });

  useEffect(() => {
    if (empresaSelecionada) {
      fetchData();
    }
  }, [empresaSelecionada]);

  const fetchData = async () => {
    try {
      const [funcionariosRes, cargosRes] = await Promise.all([
        funcionariosAPI.getAll(empresaSelecionada),
        cargosAPI.getAll(empresaSelecionada)
      ]);
      setFuncionarios(funcionariosRes.data);
      setCargos(cargosRes.data);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const fetchVeiculos = async (funcionarioId) => {
    try {
      const response = await veiculosAPI.getAll(empresaSelecionada, funcionarioId);
      setVeiculos(response.data);
    } catch (error) {
      console.error('Erro ao carregar veículos:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.cargo_id) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    try {
      const data = {
        nome: formData.nome,
        cargo_id: formData.cargo_id,
        empresa_id: empresaSelecionada,
        valor_diaria_personalizado: formData.valor_diaria_personalizado ? parseFloat(formData.valor_diaria_personalizado) : null,
        telefone: formData.telefone || null,
        cpf: formData.cpf || null,
        chave_pix: formData.chave_pix || null,
        endereco: formData.endereco || null
      };

      if (editingFuncionario) {
        await funcionariosAPI.update(editingFuncionario.id, data);
        toast.success('Funcionário atualizado com sucesso');
      } else {
        await funcionariosAPI.create(data);
        toast.success('Funcionário criado com sucesso');
      }

      setDialogOpen(false);
      setEditingFuncionario(null);
      setFormData({ nome: '', cargo_id: '', valor_diaria_personalizado: '', telefone: '', cpf: '', chave_pix: '', endereco: '' });
      fetchData();
    } catch (error) {
      console.error('Erro ao salvar funcionário:', error);
      toast.error('Erro ao salvar funcionário');
    }
  };

  const handleVeiculoSubmit = async (e) => {
    e.preventDefault();
    if (!veiculoFormData.placa) {
      toast.error('Preencha a placa do veículo');
      return;
    }

    try {
      const data = {
        funcionario_id: selectedFuncionario.id,
        placa: veiculoFormData.placa,
        modelo: veiculoFormData.modelo || null,
        ano: veiculoFormData.ano ? parseInt(veiculoFormData.ano) : null
      };

      await veiculosAPI.create(data);
      toast.success('Veículo adicionado com sucesso');
      setVeiculoFormData({ placa: '', modelo: '', ano: '' });
      fetchVeiculos(selectedFuncionario.id);
    } catch (error) {
      console.error('Erro ao adicionar veículo:', error);
      toast.error('Erro ao adicionar veículo');
    }
  };

  const handleDeleteVeiculo = async (veiculoId) => {
    try {
      await veiculosAPI.delete(veiculoId);
      toast.success('Veículo removido com sucesso');
      fetchVeiculos(selectedFuncionario.id);
    } catch (error) {
      console.error('Erro ao remover veículo:', error);
      toast.error('Erro ao remover veículo');
    }
  };

  const handleEdit = (funcionario) => {
    setEditingFuncionario(funcionario);
    setFormData({
      nome: funcionario.nome,
      cargo_id: funcionario.cargo_id,
      valor_diaria_personalizado: funcionario.valor_diaria_personalizado ? funcionario.valor_diaria_personalizado.toString() : '',
      telefone: funcionario.telefone || '',
      cpf: funcionario.cpf || '',
      chave_pix: funcionario.chave_pix || '',
      endereco: funcionario.endereco || ''
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    try {
      await funcionariosAPI.delete(funcionarioToDelete.id);
      toast.success('Funcionário deletado com sucesso');
      setDeleteDialogOpen(false);
      setFuncionarioToDelete(null);
      fetchData();
    } catch (error) {
      console.error('Erro ao deletar funcionário:', error);
      toast.error('Erro ao deletar funcionário');
    }
  };

  const openDeleteDialog = (funcionario) => {
    setFuncionarioToDelete(funcionario);
    setDeleteDialogOpen(true);
  };

  const openVeiculosDialog = (funcionario) => {
    setSelectedFuncionario(funcionario);
    fetchVeiculos(funcionario.id);
    setVeiculoDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({ nome: '', cargo_id: '', valor_diaria_personalizado: '', telefone: '', cpf: '', chave_pix: '', endereco: '' });
    setEditingFuncionario(null);
  };

  const getValorDiaria = (funcionario) => {
    const cargo = cargos.find(c => c.id === funcionario.cargo_id);
    const valorBase = funcionario.valor_diaria_personalizado || cargo?.valor_diaria_padrao || 0;
    return valorBase;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="funcionarios-title">Gestão de Equipe</h1>
        <p className="text-sm text-muted-foreground">Gerencie motoristas e ajudantes</p>
      </header>

      <Dialog open={dialogOpen} onOpenChange={(open) => {
        setDialogOpen(open);
        if (!open) resetForm();
      }}>
        <DialogTrigger asChild>
          <Button className="w-full md:w-auto mb-6 btn-accent" data-testid="add-funcionario-button">
            <Plus size={20} className="mr-2" />
            Adicionar Funcionário
          </Button>
        </DialogTrigger>
        <DialogContent className="max-h-[90vh] overflow-y-auto" data-testid="funcionario-dialog">
          <DialogHeader>
            <DialogTitle>{editingFuncionario ? 'Editar Funcionário' : 'Novo Funcionário'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="nome">Nome Completo *</Label>
              <Input
                id="nome"
                data-testid="funcionario-nome-input"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: João Silva"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="cargo">Cargo *</Label>
              <Select value={formData.cargo_id} onValueChange={(value) => setFormData({ ...formData, cargo_id: value })}>
                <SelectTrigger className="mt-1" data-testid="funcionario-cargo-select">
                  <SelectValue placeholder="Selecione um cargo" />
                </SelectTrigger>
                <SelectContent>
                  {cargos.map((cargo) => (
                    <SelectItem key={cargo.id} value={cargo.id}>
                      {cargo.nome} - R$ {cargo.valor_diaria_padrao.toFixed(2)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="valor_diaria">Valor Diária Personalizado (R$)</Label>
                <Input
                  id="valor_diaria"
                  data-testid="funcionario-valor-input"
                  type="number"
                  step="0.01"
                  value={formData.valor_diaria_personalizado}
                  onChange={(e) => setFormData({ ...formData, valor_diaria_personalizado: e.target.value })}
                  placeholder="Opcional"
                  autoComplete="off"
                  className="mt-1"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="cpf">CPF</Label>
              <Input
                id="cpf"
                data-testid="funcionario-cpf-input"
                value={formData.cpf}
                onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                placeholder="000.000.000-00"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                data-testid="funcionario-telefone-input"
                value={formData.telefone}
                onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                placeholder="(00) 00000-0000"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="chave_pix">Chave PIX</Label>
              <Input
                id="chave_pix"
                data-testid="funcionario-pix-input"
                value={formData.chave_pix}
                onChange={(e) => setFormData({ ...formData, chave_pix: e.target.value })}
                placeholder="CPF, Email, Telefone ou Chave Aleatória"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="endereco">Endereço Completo</Label>
              <Input
                id="endereco"
                data-testid="funcionario-endereco-input"
                value={formData.endereco}
                onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                placeholder="Rua, número, bairro, cidade, estado"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <Button type="submit" className="w-full" data-testid="funcionario-submit-button">
              {editingFuncionario ? 'Atualizar' : 'Criar'} Funcionário
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={veiculoDialogOpen} onOpenChange={setVeiculoDialogOpen}>
        <DialogContent data-testid="veiculo-dialog">
          <DialogHeader>
            <DialogTitle>Veículos de {selectedFuncionario?.nome}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleVeiculoSubmit} className="space-y-4 mb-4">
            <div>
              <Label htmlFor="placa">Placa *</Label>
              <Input
                id="placa"
                value={veiculoFormData.placa}
                onChange={(e) => setVeiculoFormData({ ...veiculoFormData, placa: e.target.value.toUpperCase() })}
                placeholder="ABC-1234"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="characters"
                spellCheck="false"
                className="mt-1"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="modelo">Modelo</Label>
                <Input
                  id="modelo"
                  value={veiculoFormData.modelo}
                  onChange={(e) => setVeiculoFormData({ ...veiculoFormData, modelo: e.target.value })}
                  placeholder="Ex: Scania R450"
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck="false"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="ano">Ano</Label>
                <Input
                  id="ano"
                  type="number"
                  value={veiculoFormData.ano}
                  onChange={(e) => setVeiculoFormData({ ...veiculoFormData, ano: e.target.value })}
                  placeholder="2024"
                  autoComplete="off"
                  className="mt-1"
                />
              </div>
            </div>
            <Button type="submit" className="w-full">
              <Plus size={18} className="mr-2" />
              Adicionar Veículo
            </Button>
          </form>
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-foreground">Veículos Cadastrados</h4>
            {veiculos.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum veículo cadastrado</p>
            ) : (
              veiculos.map((veiculo) => (
                <div key={veiculo.id} className="flex items-center justify-between p-3 bg-secondary rounded-md">
                  <div>
                    <p className="font-semibold text-foreground">{veiculo.placa}</p>
                    <p className="text-sm text-muted-foreground">
                      {veiculo.modelo} {veiculo.ano && `- ${veiculo.ano}`}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteVeiculo(veiculo.id)}
                    className="p-2 hover:bg-destructive/10 rounded-md transition-colors"
                  >
                    <Trash2 size={16} className="text-destructive" />
                  </button>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {funcionarios.length === 0 ? (
          <div className="col-span-full text-center py-12" data-testid="empty-funcionarios">
            <p className="text-muted-foreground">Nenhum funcionário cadastrado ainda.</p>
            <p className="text-sm text-muted-foreground mt-2">Clique no botão acima para adicionar.</p>
          </div>
        ) : (
          funcionarios.map((funcionario) => (
            <div
              key={funcionario.id}
              className="employee-card p-5 rounded-md"
              data-testid={`funcionario-card-${funcionario.id}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground">{funcionario.nome}</h3>
                  <p className="text-sm text-muted-foreground uppercase tracking-wide font-medium mt-1">
                    {funcionario.cargo_nome}
                  </p>
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => handleEdit(funcionario)}
                    className="p-2 hover:bg-secondary rounded-md transition-colors"
                    data-testid={`edit-funcionario-${funcionario.id}`}
                  >
                    <Edit2 size={18} className="text-primary" />
                  </button>
                  <button
                    onClick={() => openDeleteDialog(funcionario)}
                    className="p-2 hover:bg-destructive/10 rounded-md transition-colors"
                    data-testid={`delete-funcionario-${funcionario.id}`}
                  >
                    <Trash2 size={18} className="text-destructive" />
                  </button>
                </div>
              </div>
              <div className="space-y-2 mb-3">
                {funcionario.cpf && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CreditCard size={14} />
                    <span>{funcionario.cpf}</span>
                  </div>
                )}
                {funcionario.telefone && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone size={14} />
                    <span>{funcionario.telefone}</span>
                  </div>
                )}
                {funcionario.chave_pix && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <DollarSign size={14} />
                    <span className="text-xs">{funcionario.chave_pix}</span>
                  </div>
                )}
                {funcionario.endereco && (
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span className="flex-1 leading-tight">{funcionario.endereco}</span>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openVeiculosDialog(funcionario)}
                  data-testid={`veiculos-funcionario-${funcionario.id}`}
                >
                  <Car size={16} className="mr-2" />
                  Veículos
                </Button>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Diária Total</p>
                  <p className="text-lg font-bold text-accent">R$ {getValorDiaria(funcionario).toFixed(2)}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o funcionário "{funcionarioToDelete?.nome}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Funcionarios;