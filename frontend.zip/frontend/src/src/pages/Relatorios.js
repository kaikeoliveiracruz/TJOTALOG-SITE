import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useEmpresa } from '../context/EmpresaContext';
import { toast } from 'sonner';
import { Download, TrendingUp } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Relatorios = () => {
  const { empresaSelecionada } = useEmpresa();
  const [relatorioSemanal, setRelatorioSemanal] = useState(null);
  const [relatorioMensal, setRelatorioMensal] = useState(null);
  const [dataSemanal, setDataSemanal] = useState('');
  const [mesSelecionado, setMesSelecionado] = useState({ ano: new Date().getFullYear(), mes: new Date().getMonth() + 1 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const hoje = new Date();
    const diaSemana = hoje.getDay();
    const segundaFeira = new Date(hoje);
    segundaFeira.setDate(hoje.getDate() - (diaSemana === 0 ? 6 : diaSemana - 1));
    setDataSemanal(segundaFeira.toISOString().split('T')[0]);
  }, []);

  useEffect(() => {
    if (dataSemanal && empresaSelecionada) {
      fetchRelatorioSemanal();
    }
  }, [dataSemanal, empresaSelecionada]);

  useEffect(() => {
    if (empresaSelecionada) {
      fetchRelatorioMensal();
    }
  }, [mesSelecionado, empresaSelecionada]);

  const fetchRelatorioSemanal = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/relatorios/semanal?empresa_id=${empresaSelecionada}&data_inicio=${dataSemanal}`);
      setRelatorioSemanal(response.data);
    } catch (error) {
      console.error('Erro ao carregar relatório semanal:', error);
      toast.error('Erro ao carregar relatório semanal');
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatorioMensal = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/relatorios/mensal?empresa_id=${empresaSelecionada}&ano=${mesSelecionado.ano}&mes=${mesSelecionado.mes}`);
      setRelatorioMensal(response.data);
    } catch (error) {
      console.error('Erro ao carregar relatório mensal:', error);
      toast.error('Erro ao carregar relatório mensal');
    } finally {
      setLoading(false);
    }
  };

  const exportarCSV = async (dataInicio, dataFim) => {
    try {
      const response = await axios.get(`${API}/relatorios/export-csv?empresa_id=${empresaSelecionada}&data_inicio=${dataInicio}&data_fim=${dataFim}`, {
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `relatorio_${dataInicio}_${dataFim}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('Relatório exportado com sucesso');
    } catch (error) {
      console.error('Erro ao exportar CSV:', error);
      toast.error('Erro ao exportar relatório');
    }
  };

  const mudarSemana = (dias) => {
    const novaData = new Date(dataSemanal);
    novaData.setDate(novaData.getDate() + dias);
    setDataSemanal(novaData.toISOString().split('T')[0]);
  };

  const mudarMes = (meses) => {
    const novoMes = mesSelecionado.mes + meses;
    let ano = mesSelecionado.ano;
    let mes = novoMes;
    
    if (mes > 12) {
      mes = 1;
      ano += 1;
    } else if (mes < 1) {
      mes = 12;
      ano -= 1;
    }
    
    setMesSelecionado({ ano, mes });
  };

  const formatarData = (data) => {
    return new Date(data + 'T12:00:00').toLocaleDateString('pt-BR');
  };

  const meses = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="relatorios-title">Relatórios</h1>
        <p className="text-sm text-muted-foreground">Visualize e exporte relatórios</p>
      </header>

      <Tabs defaultValue="semanal" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="semanal" data-testid="tab-semanal">Semanal</TabsTrigger>
          <TabsTrigger value="mensal" data-testid="tab-mensal">Mensal</TabsTrigger>
        </TabsList>

        <TabsContent value="semanal" data-testid="content-semanal">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
              <Button onClick={() => mudarSemana(-7)} variant="outline" size="sm" data-testid="semana-anterior">
                ← Anterior
              </Button>
              <div className="text-center">
                <p className="text-sm font-medium text-muted-foreground">Semana de</p>
                <p className="text-base font-semibold text-foreground">
                  {relatorioSemanal && `${formatarData(relatorioSemanal.periodo.inicio)} - ${formatarData(relatorioSemanal.periodo.fim)}`}
                </p>
              </div>
              <Button onClick={() => mudarSemana(7)} variant="outline" size="sm" data-testid="semana-proxima">
                Próxima →
              </Button>
            </div>

            {relatorioSemanal && relatorioSemanal.funcionarios.length > 0 && (
              <Button
                onClick={() => exportarCSV(relatorioSemanal.periodo.inicio, relatorioSemanal.periodo.fim)}
                className="w-full btn-accent"
                data-testid="export-semanal"
              >
                <Download size={18} className="mr-2" />
                Exportar CSV
              </Button>
            )}

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : relatorioSemanal && relatorioSemanal.funcionarios.length > 0 ? (
              <div className="space-y-4">
                <div className="p-5 bg-card rounded-md border border-border">
                  <div className="flex items-center gap-3 mb-4">
                    <TrendingUp className="text-accent" size={24} />
                    <h3 className="text-lg font-semibold text-foreground">Resumo da Semana</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Dias</p>
                      <p className="text-2xl font-bold text-primary">
                        {relatorioSemanal.funcionarios.reduce((sum, f) => sum + f.total_dias, 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total em Diárias</p>
                      <p className="text-2xl font-bold text-accent">
                        R$ {relatorioSemanal.funcionarios.reduce((sum, f) => sum + f.valor_total, 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatorioSemanal.funcionarios.map((func) => (
                    <div key={func.funcionario_id} className="employee-card p-5 rounded-md" data-testid={`relatorio-func-${func.funcionario_id}`}>
                      <h4 className="font-semibold text-foreground mb-3">{func.funcionario_nome}</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Dias Trabalhados</p>
                          <p className="text-xl font-bold text-primary">{func.total_dias}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
                          <p className="text-xl font-bold text-accent">R$ {func.valor_total.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12" data-testid="empty-semanal">
                <p className="text-muted-foreground">Nenhum dado para esta semana.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="mensal" data-testid="content-mensal">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
              <Button onClick={() => mudarMes(-1)} variant="outline" size="sm" data-testid="mes-anterior">
                ← Anterior
              </Button>
              <div className="text-center">
                <p className="text-base font-semibold text-foreground">
                  {meses[mesSelecionado.mes - 1]} {mesSelecionado.ano}
                </p>
              </div>
              <Button onClick={() => mudarMes(1)} variant="outline" size="sm" data-testid="mes-proximo">
                Próximo →
              </Button>
            </div>

            {relatorioMensal && relatorioMensal.funcionarios.length > 0 && (
              <Button
                onClick={() => exportarCSV(relatorioMensal.periodo.inicio, relatorioMensal.periodo.fim)}
                className="w-full btn-accent"
                data-testid="export-mensal"
              >
                <Download size={18} className="mr-2" />
                Exportar CSV
              </Button>
            )}

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : relatorioMensal && relatorioMensal.funcionarios.length > 0 ? (
              <div className="space-y-4">
                <div className="p-5 bg-card rounded-md border border-border">
                  <div className="flex items-center gap-3 mb-4">
                    <TrendingUp className="text-accent" size={24} />
                    <h3 className="text-lg font-semibold text-foreground">Resumo do Mês</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Dias</p>
                      <p className="text-2xl font-bold text-primary">
                        {relatorioMensal.funcionarios.reduce((sum, f) => sum + f.total_dias, 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total em Diárias</p>
                      <p className="text-2xl font-bold text-accent">
                        R$ {relatorioMensal.funcionarios.reduce((sum, f) => sum + f.valor_total, 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-5 bg-card rounded-md border border-border">
                  <h4 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wide">Gráfico de Dias Trabalhados</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={relatorioMensal.funcionarios}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="funcionario_nome" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="total_dias" fill="hsl(var(--accent))" name="Dias" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {relatorioMensal.funcionarios.map((func) => (
                    <div key={func.funcionario_id} className="employee-card p-5 rounded-md" data-testid={`relatorio-mensal-func-${func.funcionario_id}`}>
                      <h4 className="font-semibold text-foreground mb-3">{func.funcionario_nome}</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Dias Trabalhados</p>
                          <p className="text-xl font-bold text-primary">{func.total_dias}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
                          <p className="text-xl font-bold text-accent">R$ {func.valor_total.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12" data-testid="empty-mensal">
                <p className="text-muted-foreground">Nenhum dado para este mês.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Relatorios;