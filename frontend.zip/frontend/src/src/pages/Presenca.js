import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useEmpresa } from '../context/EmpresaContext';
import { toast } from 'sonner';
import { Calendar } from 'lucide-react';
import { Button } from '../components/ui/button';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Presenca = () => {
  const { empresaSelecionada } = useEmpresa();
  const [funcionarios, setFuncionarios] = useState([]);
  const [presencas, setPresencas] = useState({});
  const [dataAtual, setDataAtual] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (empresaSelecionada) {
      fetchData();
    }
  }, [dataAtual, empresaSelecionada]);

  const fetchData = async () => {
    try {
      const [funcionariosRes, presencasRes] = await Promise.all([
        axios.get(`${API}/funcionarios?empresa_id=${empresaSelecionada}`),
        axios.get(`${API}/presencas/dia/${dataAtual}?empresa_id=${empresaSelecionada}`)
      ]);
      
      setFuncionarios(funcionariosRes.data);
      
      const presencasMap = {};
      presencasRes.data.forEach(p => {
        presencasMap[p.funcionario_id] = p.presente;
      });
      setPresencas(presencasMap);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const togglePresenca = async (funcionarioId, presente) => {
    try {
      await axios.post(`${API}/presencas`, {
        funcionario_id: funcionarioId,
        empresa_id: empresaSelecionada,
        data: dataAtual,
        presente: presente
      });
      
      setPresencas(prev => ({ ...prev, [funcionarioId]: presente }));
      toast.success(presente ? 'Presença marcada' : 'Ausência marcada');
    } catch (error) {
      console.error('Erro ao registrar presença:', error);
      toast.error('Erro ao registrar presença');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  const dataObj = new Date(dataAtual + 'T12:00:00');
  const dataFormatada = dataObj.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  const diaSemana = dataObj.toLocaleDateString('pt-BR', { weekday: 'long' });

  const totalPresentes = Object.values(presencas).filter(p => p === true).length;
  const totalAusentes = Object.values(presencas).filter(p => p === false).length;
  const totalMarcados = totalPresentes + totalAusentes;

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="presenca-title">Registro de Presença</h1>
        <p className="text-sm text-muted-foreground">Marque a presença da equipe em qualquer dia</p>
      </header>

      <div className="mb-6 p-5 bg-card rounded-md border border-border">
        <div className="flex items-center gap-3 mb-3">
          <Calendar className="text-accent" size={24} />
          <div>
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">{diaSemana}</p>
            <p className="text-base font-semibold text-foreground">{dataFormatada}</p>
          </div>
        </div>
        <input
          type="date"
          value={dataAtual}
          onChange={(e) => setDataAtual(e.target.value)}
          className="w-full p-3 border border-input rounded-md bg-background text-foreground"
          data-testid="date-picker"
        />
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-secondary rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Marcados</p>
            <p className="text-2xl font-bold text-primary">{totalMarcados}</p>
          </div>
          <div className="text-center p-3 bg-success/10 rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Presentes</p>
            <p className="text-2xl font-bold text-success">{totalPresentes}</p>
          </div>
          <div className="text-center p-3 bg-destructive/10 rounded-md">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Ausentes</p>
            <p className="text-2xl font-bold text-destructive">{totalAusentes}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {funcionarios.length === 0 ? (
          <div className="col-span-full text-center py-12" data-testid="empty-funcionarios-presenca">
            <p className="text-muted-foreground">Nenhum funcionário cadastrado.</p>
            <p className="text-sm text-muted-foreground mt-2">Adicione funcionários primeiro.</p>
          </div>
        ) : (
          funcionarios.map((funcionario) => {
            const presente = presencas[funcionario.id];
            return (
              <div
                key={funcionario.id}
                className="employee-card p-5 rounded-md"
                data-testid={`presenca-card-${funcionario.id}`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{funcionario.nome}</h3>
                    <p className="text-sm text-muted-foreground uppercase tracking-wide font-medium mt-1">
                      {funcionario.cargo_nome}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => togglePresenca(funcionario.id, true)}
                    className={`presence-toggle ${
                      presente === true
                        ? 'bg-success text-white hover:bg-success/90'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                    data-testid={`presenca-sim-${funcionario.id}`}
                  >
                    Presente
                  </Button>
                  <Button
                    onClick={() => togglePresenca(funcionario.id, false)}
                    className={`presence-toggle ${
                      presente === false
                        ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                    data-testid={`presenca-nao-${funcionario.id}`}
                  >
                    Ausente
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Presenca;
