import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useEmpresa } from '../context/EmpresaContext';
import { toast } from 'sonner';
import { Calendar, CheckCircle, XCircle, Filter } from 'lucide-react';
import { Button } from '../components/ui/button';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Historico = () => {
  const { empresaSelecionada } = useEmpresa();
  const [presencas, setPresencas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dataInicio, setDataInicio] = useState('');
  const [dataFim, setDataFim] = useState('');
  const [filtroAtivo, setFiltroAtivo] = useState(false);

  useEffect(() => {
    const hoje = new Date();
    const trintaDiasAtras = new Date(hoje);
    trintaDiasAtras.setDate(hoje.getDate() - 30);
    
    setDataInicio(trintaDiasAtras.toISOString().split('T')[0]);
    setDataFim(hoje.toISOString().split('T')[0]);
  }, []);

  useEffect(() => {
    if (dataInicio && dataFim && empresaSelecionada) {
      fetchPresencas();
    }
  }, [dataInicio, dataFim, empresaSelecionada]);

  const fetchPresencas = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/presencas?empresa_id=${empresaSelecionada}&data_inicio=${dataInicio}&data_fim=${dataFim}`);
      setPresencas(response.data);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
      toast.error('Erro ao carregar histórico');
    } finally {
      setLoading(false);
    }
  };

  const aplicarFiltro = () => {
    fetchPresencas();
    setFiltroAtivo(false);
    toast.success('Filtro aplicado');
  };

  const formatarData = (data) => {
    const d = new Date(data + 'T12:00:00');
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const formatarDiaSemana = (data) => {
    const d = new Date(data + 'T12:00:00');
    return d.toLocaleDateString('pt-BR', { weekday: 'short' });
  };

  const agruparPorData = () => {
    const grupos = {};
    presencas.forEach(presenca => {
      if (!grupos[presenca.data]) {
        grupos[presenca.data] = [];
      }
      grupos[presenca.data].push(presenca);
    });
    return grupos;
  };

  const gruposPresenca = agruparPorData();
  const datas = Object.keys(gruposPresenca).sort().reverse();

  const totalPresencas = presencas.filter(p => p.presente).length;
  const totalAusencias = presencas.filter(p => !p.presente).length;
  const totalDiarias = presencas.filter(p => p.presente).reduce((sum, p) => sum + p.valor_diaria, 0);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      <header className="mb-6 mt-4">
        <h1 className="page-header text-3xl md:text-4xl text-primary mb-2" data-testid="historico-title">Histórico</h1>
        <p className="text-sm text-muted-foreground">Visualize o histórico completo de presenças</p>
      </header>

      <div className="mb-6 space-y-4">
        <Button
          onClick={() => setFiltroAtivo(!filtroAtivo)}
          variant="outline"
          className="w-full md:w-auto"
          data-testid="toggle-filter"
        >
          <Filter size={18} className="mr-2" />
          {filtroAtivo ? 'Fechar Filtro' : 'Filtrar Período'}
        </Button>

        {filtroAtivo && (
          <div className="p-4 bg-card rounded-md border border-border space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground">Data Início</label>
                <input
                  type="date"
                  value={dataInicio}
                  onChange={(e) => setDataInicio(e.target.value)}
                  className="w-full mt-1 p-2 border border-input rounded-md bg-background text-foreground"
                  data-testid="filter-data-inicio"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Data Fim</label>
                <input
                  type="date"
                  value={dataFim}
                  onChange={(e) => setDataFim(e.target.value)}
                  className="w-full mt-1 p-2 border border-input rounded-md bg-background text-foreground"
                  data-testid="filter-data-fim"
                />
              </div>
            </div>
            <Button onClick={aplicarFiltro} className="w-full" data-testid="apply-filter">
              Aplicar Filtro
            </Button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-card rounded-md border border-border text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Presenças</p>
            <p className="text-3xl font-bold text-success mt-1">{totalPresencas}</p>
          </div>
          <div className="p-4 bg-card rounded-md border border-border text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Ausências</p>
            <p className="text-3xl font-bold text-destructive mt-1">{totalAusencias}</p>
          </div>
          <div className="p-4 bg-card rounded-md border border-border text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Total R$</p>
            <p className="text-3xl font-bold text-accent mt-1">{totalDiarias.toFixed(0)}</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {datas.length === 0 ? (
          <div className="text-center py-12" data-testid="empty-historico">
            <p className="text-muted-foreground">Nenhum registro encontrado neste período.</p>
          </div>
        ) : (
          datas.map((data) => (
            <div key={data} className="space-y-3" data-testid={`historico-dia-${data}`}>
              <div className="flex items-center gap-3">
                <Calendar size={20} className="text-accent" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                    {formatarDiaSemana(data)}
                  </p>
                  <p className="text-base font-semibold text-foreground">{formatarData(data)}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 ml-0 md:ml-8">
                {gruposPresenca[data].map((presenca) => (
                  <div
                    key={presenca.id}
                    className="employee-card p-4 rounded-md flex items-center justify-between"
                    data-testid={`presenca-item-${presenca.id}`}
                  >
                    <div>
                      <p className="font-semibold text-foreground">{presenca.funcionario_nome}</p>
                      {presenca.presente && (
                        <p className="text-sm text-accent font-medium">R$ {presenca.valor_diaria.toFixed(2)}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {presenca.presente ? (
                        <div className="flex items-center gap-2 text-success">
                          <CheckCircle size={20} />
                          <span className="text-sm font-medium">Presente</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-destructive">
                          <XCircle size={20} />
                          <span className="text-sm font-medium">Ausente</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Historico;