import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { EmpresaProvider, useEmpresa } from './context/EmpresaContext';
import SelecionarEmpresa from './pages/SelecionarEmpresa';
import Dashboard from './pages/Dashboard';
import Funcionarios from './pages/Funcionarios';
import Cargos from './pages/Cargos';
import Presenca from './pages/Presenca';
import Relatorios from './pages/Relatorios';
import Historico from './pages/Historico';
import Empresas from './pages/Empresas';
import BottomNav from './components/BottomNav';
import { Toaster } from './components/ui/sonner';
import './App.css';

const ProtectedRoutes = () => {
  const { empresaSelecionada, loading } = useEmpresa();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!empresaSelecionada) {
    return <Navigate to="/selecionar-empresa" replace />;
  }

  return (
    <div className="pb-nav">
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/funcionarios" element={<Funcionarios />} />
        <Route path="/cargos" element={<Cargos />} />
        <Route path="/presenca" element={<Presenca />} />
        <Route path="/relatorios" element={<Relatorios />} />
        <Route path="/historico" element={<Historico />} />
        <Route path="/empresas" element={<Empresas />} />
      </Routes>
      <BottomNav />
    </div>
  );
};

function App() {
  return (
    <div className="app-container">
      <EmpresaProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/selecionar-empresa" element={<SelecionarEmpresa />} />
            <Route path="/*" element={<ProtectedRoutes />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-center" />
      </EmpresaProvider>
    </div>
  );
}

export default App;