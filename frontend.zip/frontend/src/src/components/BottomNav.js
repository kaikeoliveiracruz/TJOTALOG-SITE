import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Users, Briefcase, CheckSquare, BarChart3, Building2 } from 'lucide-react';

const BottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'Início' },
    { path: '/funcionarios', icon: Users, label: 'Equipe' },
    { path: '/cargos', icon: Briefcase, label: 'Cargos' },
    { path: '/presenca', icon: CheckSquare, label: 'Presença' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },
    { path: '/empresas', icon: Building2, label: 'Empresa' }
  ];

  return (
    <nav className="bottom-nav">
      <div className="max-w-7xl mx-auto flex justify-around items-center">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`nav-item ${isActive ? 'active' : ''}`}
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <Icon size={20} />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;